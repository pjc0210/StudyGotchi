import numpy as np
from scipy.optimize import minimize

def objective_function(x_array):
    """
    The function to minimize: f(x) = 2*np.pi*x**2 + 2*V/x
    
    Args:
        x_array: A 1D array containing the variable
                              
    Returns:
        float: The function value f(x).
    """
    # Extract the single variable from the 1D array
    x = x_array[0]
    V = 800
    # Calculate the function value
    return 2*np.pi*x**2 + 2*V/x


# Define the initial guess
# We choose a starting point at x=1.0
x_initial_guess = np.array([1.0]) 

# Call scipy.minimize
# We explicitly choose the 'BFGS' method
result = minimize(
    fun=objective_function,
    x0=x_initial_guess,
    method='BFGS',
    tol=1e-6)


# TODO - unconstrained
# print the optimal x
# print the number of iterations

# TODO - constrained
# edit the code to add xontraint x <=3
#print the optimal x


