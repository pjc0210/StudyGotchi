################################################################################
# CSE.C20 Fall 2023
# Problem Set 3: run_tests
# Name: Frank Gonzalez
# Collaborators: Victor Long


import numpy as np
import matplotlib.pyplot as plt
import gd


def J0(xv):
    """
    Calculates J0 objective function and its gradient (see pset desription).

    Args:
        xv (1D numpy array): for this problem, only one value (xv[0]) will be present

    Returns:
        J0 (float): objective function at x = xv[0]
        J0prime (1D numpy array): gradient of J0 at x = xv[0]
    """
    x = xv[0]
    J0 = (x-0.5)**2
    J0prime = 2 * (x-0.5)
    return J0, J0prime


def J1(xv, pdict):
    """
    Calculates J1 objective function and its gradient (see pset desription).

    Args:
        xv (1D numpy array): x = xv[0], y = xv[1]
        pdict (dictionary): contains the key 'user' with the associated value referring
            to the user location such that:
                pdict['user'][0] is the x-location of the user (x^u)
                pdict['user'][1] is the y-location of the user (y^u)

    Returns:
        J1 (float): objective function at xv
        J1prime (1D numpy array): gradient of J1 at xv
    """
    #### BEGIN SOLUTION ####
    x = xv[0]
    y = xv[1]
    x_u = pdict['user'][0]
    y_u = pdict['user'][1]
    
    # J1 = -1 / (1 + (x - x^u)^2 + (y - y^u)^2)
    denom = 1 + (x - x_u)**2 + (y - y_u)**2
    J1 = -1 / denom
    
    # Gradient: dJ1/dx = 2(x - x^u) / (1 + (x - x^u)^2 + (y - y^u)^2)^2
    #           dJ1/dy = 2(y - y^u) / (1 + (x - x^u)^2 + (y - y^u)^2)^2
    J1prime = np.array([
        2 * (x - x_u) / (denom**2),
        2 * (y - y_u) / (denom**2)
    ])
    
    return J1, J1prime
    #### END SOLUTION ####


def run_test0():
    print()
    print("Running test0")
    xstart = np.array([-0.5])
    alpha = 0.1
    nStop = 40
    xhist, Jhist = gd.gradient_descent(J0, xstart, alpha, nStop, verbose=True)
    print(f"In run_test0: xopt = {xhist[-1,0]:.2e}, Jmin = {Jhist[-1]:.2e}")


def run_test1():
    print()
    print("Running test1")
    pdict = {}
    pdict['user'] = np.array([0.5, -0.25])
    xstart = np.array([0., 0.])
    alpha = 0.1
    nStop = 40
    xhist, Jhist = gd.gradient_descent(J1, xstart, alpha, nStop, verbose=True, pdict=pdict)
    print(f"In run_test1: (xopt, yopt) = ({xhist[-1,0]:.2e}, {xhist[-1,1]:.2e}), Jmin = {Jhist[-1]:.2e}")

    # Set up linearly spaced points in x and y for evaluating objective function
    Nx = 101
    Ny = 101
    bx = np.linspace(-1., 1., Nx)
    by = np.linspace(-1., 1., Ny)
    f = np.zeros((Nx, Ny))

    #### BEGIN SOLUTION ####
    for i in range(Nx):
        for j in range(Ny):
            xv = np.array([bx[i], by[j]])
            f[i, j], _ = J1(xv, pdict)
    
    # Plot contours of J1 
    fig, ax = plt.subplots(figsize=(8, 8))
    # Create contour levels 
    levels = np.linspace(0, 1.0, 9)
    cs = ax.contour(bx, by, -f.T, levels=levels)
    ax.clabel(cs, inline=True, fontsize=8)
    
    ax.plot(xhist[:, 0], xhist[:, 1], marker='o', color='green', linestyle='none', 
            markersize=5)
    
    # Mark the final state
    ax.plot(xhist[-1, 0], xhist[-1, 1], marker='o', color='magenta', linestyle='none',
            markersize=8)
    
    ax.set_xlabel('x')
    ax.set_ylabel('y')
    # ax.set_title('Gradient Descent on J1')
    ax.set_aspect('equal')
    ax.set_xlim(-1.0, 1.0)
    ax.set_ylim(-1.0, 1.0)
    ax.grid(True, alpha=0.3)
    ax.legend()
    #### END SOLUTION ####

    return ax, cs


if __name__ == '__main__':
    run_test0()
    run_test1()
    plt.show()