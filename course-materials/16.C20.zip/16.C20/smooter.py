################################################################################
# Smooter income and expense functions
#

import numpy as np

def Ifunc(x):
    """
    Calculates the income I(x) and the gradient Iprime(x) generated
    for the Smooter given the design state vector x.

    Args:
        x (1D numpy array): design state vector to calculate I(x) and Iprime(x)

    Returns:
        I (float): the income evaluated for design state x

        Iprime (1D numpy array of floats): the gradient of I with respect to x
            evaluated for design state x
    """
    I = 6.063131115128254 - x[0]**2 - (x[1]-0.1)**2 - x[2]**2
    Iprime = np.zeros(x.shape)
    Iprime[0] = -2*x[0]
    Iprime[1] = -2*(x[1]-0.1)
    Iprime[2] = -2*x[2]

    return I, Iprime

def Efunc(x):
    """
    Calculates the expense E(x) and the gradient Eprime(x) to produce
    the Smooter given the design state vector x.

    Args:
        x (1D numpy array): design state vector to calculate E(x) and Eprime(x)

    Returns:
        E (float): the expense evaluated for design state x

        Eprime (1D numpy array of floats): the gradient of E with respect to x
            evaluated for design state x
    """
    E = 0.5 + (x[0]-1.2)**2 + (x[1]-0.1)**2 + (1+(x[2]-0.2)**2)**(-1)
    Eprime = np.zeros(x.shape)
    Eprime[0] = 2*(x[0]-1.2)
    Eprime[1] = 2*(x[1]-0.1)
    Eprime[2] = -((1+(x[2]-0.2)**2)**(-2))*(2*(x[2]-0.2))

    return E, Eprime
