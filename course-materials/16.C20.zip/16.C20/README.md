# 16.C20 coding coursework

Local assignment code and lecture examples, including numerical integration, linear and nonlinear solvers, optimization, and neuron simulations. The resource directories preserve different working versions. Some files contain completed student solutions. These are coursework examples, not a tested software package.

Python and CSV files are included. Editor artifacts, caches, platform configuration, and the old environment export are excluded.
