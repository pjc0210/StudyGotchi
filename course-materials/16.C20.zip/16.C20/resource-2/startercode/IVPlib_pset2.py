################################################################################
# CSE.C20
# Problem Set 2: IVPlib_pset2
# Name: Frank Gonzalez
# Collaborators: Victor Long
################################################################################

import copy
import numpy as np
from mynonlinsolver import myNewton


class IVP():

    def __init__(self, uI, tI, tF, p={}):
        self._uI = uI.copy()
        self._tI = tI
        self._tF = tF
        self._p = copy.deepcopy(p)

    def __len__(self):
        return len(self._uI)

    def evalf(self, u, t):
        raise NotImplementedError("evalf is not implemented for this class")

    def plotstate(self, u, plotdict, t=None):
        raise NotImplementedError("plotstate is not implemented for this class")

    def get_tI(self):
        return self._tI

    def get_tF(self):
        return self._tF

    def get_uI(self):
        return self._uI.copy()

    def get_p(self, name):
        return self._p[name]


################################################################################
## Time integration methods
################################################################################


def step_FE(thisIVP, dt, un, tn):
    fn = thisIVP.evalf(un, tn)
    un1 = un + dt * fn
    return un1


def step_RK2_ME(thisIVP, dt, un, tn):
    a = dt * thisIVP.evalf(un, tn)
    b = dt * thisIVP.evalf(un + 0.5 * a, tn + 0.5 * dt)
    un1 = un + b
    return un1


def step_BE(thisIVP, dt, un, tn):
    """
    Takes a single timestep of the Backward Euler method (BE) to
    (approximately) integrate the state from u(tn) to u(tn+dt)
    """
    def evalr(v):
        # Residual function for implicit equation
        return (v - un)/dt - thisIVP.evalf(v, tn + dt)

    def evalr_u(v):
        # Jacobian of residual
        return np.eye(len(v))/dt - thisIVP.evalf_u(v, tn + dt)

    # --- Newton’s method call ---
    u_guess = un.copy()
    un1 = myNewton(u_guess, evalr, evalr_u)
    return un1


def solve(thisIVP, dt, method, plotdict=None):
    tI = thisIVP.get_tI()
    tF = thisIVP.get_tF()
    uI = thisIVP.get_uI()

    M = len(uI)
    t = np.arange(tI, tF + dt, dt)
    N = len(t)
    u = np.zeros((N, M))
    u[0, :] = uI

    for n in range(1, N):
        u[n, :] = method(thisIVP, dt, u[n-1, :], t[n-1])
        if plotdict is not None:
            if (n % plotdict['freq'] == 0) or (n == N - 1):
                thisIVP.plotstate(u[n, :], plotdict, t=t[n])

    return t, u