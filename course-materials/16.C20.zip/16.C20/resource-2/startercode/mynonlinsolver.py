################################################################################
# CSE.C20
# Problem Set 2: mynonlinsolver
# Name: Frank Gonzalez
# Collaborators: Victor Long
################################################################################

import numpy as np

def myNewton(u0, evalr, evalr_u, numNewton=10, atol=1.0e-12, rtol=1.0e-12):
    """
    Implements Newton's method to find u such that evalr(u) = 0.

    Args:
        u0 (NumPy ndarray): initial guess for solution
        evalr (function): function handle that evaluates r(u)
        evalr_u (function): function handle that evaluates Jacobian dr/du
        numNewton (int): maximum number of Newton iterations
        atol (float): absolute tolerance for stopping
        rtol (float): relative tolerance for stopping

    Returns:
        NumPy ndarray: approximate solution u* such that r(u*) ≈ 0
    """
    uNewton = u0.copy()

    for k in range(numNewton):
        r = evalr(uNewton)
        J = evalr_u(uNewton)

        # Solve J * delta = -r
        delta_u = np.linalg.solve(J, -r)
        uNewton = uNewton + delta_u

        # Convergence check
        if np.linalg.norm(r) < atol + rtol * np.linalg.norm(uNewton):
            break

    return uNewton


###############################################################################
# Basic tester
###############################################################################
if __name__ == "__main__":

    def evalr(u):
        return np.array([
            u[0]**2 + u[1]**2 - 1.0,
            np.exp(u[0]-1.0) + u[1] - 1.0
        ])

    def evalr_u(u):
        return np.array([
            [2.0*u[0], 2.0*u[1]],
            [np.exp(u[0]-1.0), 1.0]
        ])

    u0 = np.array([1.0, 0.0])

    # Run 2 iterations
    u2 = myNewton(u0, evalr, evalr_u, numNewton=2)
    print("Result of a 2 iteration Newton solve:")
    print("u2    = [{: .6e} {: .6e}]".format(u2[0], u2[1]))
    r2 = evalr(u2)
    print("r(u2) = [{: .6e} {: .6e}]".format(r2[0], r2[1]))
    u_correct = np.array([1.016920, -5.679316e-02])
    print("Does solution = correct solution:", np.allclose(u2, u_correct, atol=1e-6))

    # Run 10 iterations 
    u10 = myNewton(u0, evalr, evalr_u, numNewton=10)
    print("\nResult of a 10 iteration Newton solve:")
    print("u10    = [{: .6e} {: .6e}]".format(u10[0], u10[1]))
    r10 = evalr(u10)
    print("r(u10) = [{: .6e} {: .6e}]".format(r10[0], r10[1]))
    u_correct2 = np.array([1.0, 1.299920e-17])
    print("Does solution = correct solution:", np.allclose(u10, u_correct2, atol=1e-6))